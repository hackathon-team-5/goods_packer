# Getting Started with Create React App

- git clone
- npm i
