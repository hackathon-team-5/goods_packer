import React from "react";

export const CompletedContext = React.createContext();
