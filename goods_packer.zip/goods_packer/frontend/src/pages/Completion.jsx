import React from "react";
import Completetin from "../components/Сompletion";
import Header from "../components/Header";
import Footer from "../components/Footer"

const Completion = () => {
  return (
    <>
      <Header />
      <Completetin />
      <Footer />
    </>
  );
};

export default Completion;
